//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ClientApp.rc
//
#define IDD_CLIENTAPP_DIALOG            100
#define IDR_MAINFRAME                   101
#define IDC_PAGENUM                     1000
#define IDC_PAGENUMCMD                  1001
#define IDC_ADDNOTECMD                  1002
#define IDC_TEXTEDIT                    1003
#define IDC_PERFORMOP                   1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
