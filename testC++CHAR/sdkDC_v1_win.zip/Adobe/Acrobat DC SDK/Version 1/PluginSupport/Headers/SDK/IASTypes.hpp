// This has been renamed
#include "IADMTypes.hpp"
