// This has been renamed
#include "IADMRect.hpp"
